PeriFEM（近场有限单元法）
二维平面应力问题
只能添加位移边界条件
采用四节点单元  
数据类型：double
CUDA：.cu 并行 

选择模型后需要修改头文件中各项参数：
E 	 		弹性模量
NODE 	 		结点数
ELE             		单元数
grid_length      		网格尺寸
delta 			近场半径
s_crit 			临界伸长率
L  			长度尺度参数
skip_size                     	每个单元的相关单元个数最大值
skip_size_half 		一半的相关单元数组
node_to_node_skip                   节点关系，用于计算CSR索引，当出错时尝试调大此值，
其含义为划分的网格中：一个节点被几个单元共享后，这几个单元的节点总数

此代码的关键修改步骤：
1.将网格文件拷贝至“mesh”文件夹中
2.修改“function.cuh”文件中的模型参数：E、NODE、ELE、grid_length、delta等
3.添加预制裂纹或屏蔽掉跨边界或者缺口两侧的非物理键：“function.cu”中的“device_find_related_element”函数
4.修改边界条件：“function.cu”中的“kernel_deal_bc”函数
5.屏蔽掉边界某些局部区域使该区域中的键不更新断键操作：“function.cu”中的“kernel_update_bond”函数
6.输出支反力F的范围修改：”function.cu“中的”export_result_load“支反力范围修改
6.“main.cu”中修改两个“while”循环中的”displacenment“值，添加加载位移增量步与最大加载位移值
8.运行即可

